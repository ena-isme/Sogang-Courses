#include "list.h"
#include "bitmap.h"
#include "hash.h"
#include "hex_dump.h"
#include "debug.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_LISTS 10
#define MAX_BITMAPS 10

struct list* lists[MAX_LISTS];
struct bitmap* bitmaps[MAX_BITMAPS];

struct list_item {
    struct list_elem elem;
    int data;
};

bool less(const struct list_elem *a, const struct list_elem *b, void *aux) {
    struct list_item *item_a = list_entry(a, struct list_item, elem);
    struct list_item *item_b = list_entry(b, struct list_item, elem);
    return item_a->data < item_b->data;
}

int find_bitmap_index(const char* name) {
    return atoi(name + 2);
}

int main() {
    struct list my_list, my_list2;
    list_init(&my_list);
    list_init(&my_list2);

    char input[256], command[20], type[20], name[20];
    int arg, arg2;
    struct bitmap *bm0 = NULL;

    while (1) {
        fflush(stdout);

        if (!fgets(input, sizeof(input), stdin)) {
            continue;
        }

        if (sscanf(input, "%s", command) != 1) {
            continue;
        }

        if (strcmp(command, "create") == 0) {
            if (sscanf(input, "create %s %s %d", type, name, &arg) == 3) {
                if (strcmp(type, "list") == 0) {
                    int idx = atoi(name + 4);
                    if (idx >= 0 && idx < MAX_LISTS) {
                        lists[idx] = malloc(sizeof(struct list));
                        list_init(lists[idx]);
                    }

                } else if (strcmp(type, "bitmap") == 0) {
                    int idx = atoi(name + 2);
                    if (idx >= 0 && idx < MAX_BITMAPS) {
                        bitmaps[idx] = bitmap_create(arg);
                    }
                }
            }
        }

        // MARK: Quit

        else if (strcmp(command, "quit") == 0) {
            while (!list_empty(&my_list)) {
                struct list_elem *e = list_pop_front(&my_list);
                struct list_item *item = list_entry(e, struct list_item, elem);
                free(item);
            }

            while (!list_empty(&my_list2)) {
                struct list_elem *e = list_pop_front(&my_list2);
                struct list_item *item = list_entry(e, struct list_item, elem);
                free(item);
            }
            break;
        }
        
        // MARK: Dumpdata

        else if (strcmp(command, "dumpdata") == 0) {
            char name[100];
            struct list_elem *e;
            struct list *targetList = NULL;
            if (sscanf(input, "%s %s", command, name) == 2) {
                // List 처리
                if (strcmp(name, "list0") == 0) {
                    targetList = &my_list;
                    for (e = list_begin(targetList); e != list_end(targetList); e = list_next(e)) {
                        struct list_item *item = list_entry(e, struct list_item, elem);
                        printf("%d ", item->data);
                    }
                printf("\n");
                } else if (strcmp(name, "list1") == 0) {
                    targetList = &my_list2;
                    for (e = list_begin(targetList); e != list_end(targetList); e = list_next(e)) {
                        struct list_item *item = list_entry(e, struct list_item, elem);
                        printf("%d ", item->data);
                    }
                    printf("\n");
                }

                // Bitmap 처리
                else if (strncmp(name, "bm", 2) == 0) {
                    int idx = atoi(name + 2);
                    if (idx >= 0 && idx < MAX_BITMAPS && bitmaps[idx] != NULL) {
                        struct bitmap *bm = bitmaps[idx];
                        size_t bm_size = bitmap_size(bm);
                        for (size_t i = 0; i < bm_size; i++) {
                            printf("%d", bitmap_test(bm, i) ? 1 : 0);
                        }
                        printf("\n");
                    }
                }
            }
        }

        // MARK: Delete

        else if (strcmp(command, "delete") == 0) {
            char listName[100];
            struct list *targetList = NULL;

            if (sscanf(input, "%*s %s", listName) == 1) {
                if (strcmp(listName, "list0") == 0) {
                    targetList = &my_list;
                } else if (strcmp(listName, "list1") == 0) {
                    targetList = &my_list2;
                }

                if (targetList != NULL) {
                    while (!list_empty(targetList)) {
                        struct list_elem *e = list_pop_front(targetList);
                        struct list_item *item = list_entry(e, struct list_item, elem);
                        free(item);
                    }
                }
            }
        }

        // MARK: Empty

        else if (strcmp(command, "list_empty") == 0) {
            char listName[100];
            if (sscanf(input, "%s %s", command, listName) == 2) {
                if (!list_empty(&my_list)) {
                    printf("false\n");
                } else {
                    printf("true\n");
                }
            }
        }

        // MARK: List

        else if (strcmp(command, "list_front") == 0) {
            char listName[100];
            if (sscanf(input, "%s %s", command, listName) == 2) {
                if (!list_empty(&my_list)) {
                    struct list_elem *front_elem = list_front(&my_list);
                    struct list_item *item = list_entry(front_elem, struct list_item, elem);
                    printf("%d\n", item->data);
                }
            }
        }

        else if (strcmp(command, "list_back") == 0) {
            char listName[100];
            if (sscanf(input, "%s %s", command, listName) == 2) {
                if (!list_empty(&my_list)) {
                    struct list_elem *back_elem = list_back(&my_list);
                    struct list_item *item = list_entry(back_elem, struct list_item, elem);
                    printf("%d\n", item->data);
                }
            }
        }

        else if (strcmp(command, "list_push_front") == 0) {
            char listName[100];
            int value;
            if (sscanf(input, "%s %s %d", command, listName, &value) == 3) {
                struct list_item *item = malloc(sizeof(struct list_item));
                item->data = value;
                list_push_front(&my_list, &item->elem);
             }
        }

        else if (strcmp(command, "list_push_back") == 0) {
            char listName[100];
            int value;
            struct list *targetList = NULL;

            if (sscanf(input, "%s %s %d", command, listName, &value) == 3) {
                if (strcmp(listName, "list0") == 0) {
                    targetList = &my_list;
                } else if (strcmp(listName, "list1") == 0) {
                    targetList = &my_list2;
                }

                if (targetList != NULL) {
                    struct list_item *item = malloc(sizeof(struct list_item));
                    item->data = value;
                    list_push_back(targetList, &item->elem);
                }
            }
        }

        else if (strcmp(command, "list_pop_front") == 0) {
            if (!list_empty(&my_list)) {
                struct list_elem *e = list_pop_front(&my_list);
                struct list_item *item = list_entry(e, struct list_item, elem);
                free(item);
            }
        }

        else if (strcmp(command, "list_pop_back") == 0) {
            if (!list_empty(&my_list)) {
                struct list_elem *e = list_pop_back(&my_list);
                struct list_item *item = list_entry(e, struct list_item, elem);
                free(item);
            }
        }

        else if (strcmp(command, "list_remove") == 0) {
            char listName[100];
            int index;
            if (sscanf(input, "%*s %s %d", listName, &index) == 2) {
                struct list *targetList = NULL;

                if (strcmp(listName, "list0") == 0) {
                    targetList = &my_list;
                }

            if (targetList != NULL && !list_empty(targetList)) {
                    struct list_elem *e = list_begin(targetList);
                    for (int i = 0; e != list_end(targetList) && i < index; i++) {
                        e = list_next(e);
                    }

                    if (e != list_end(targetList)) {
                        list_remove(e);
                    }
               }
            }
        }

        else if (strcmp(command, "list_insert") == 0) {
            char listName[100];
            int index, value;
            if (sscanf(input, "%*s %s %d %d", listName, &index, &value) == 3) {
                struct list_item *new_item = malloc(sizeof(struct list_item));
                new_item->data = value;

                struct list_elem *e = list_begin(&my_list);
                for (int i = 0; i < index && e != list_end(&my_list); i++) {
                    e = list_next(e);
                }
                list_insert(e, &new_item->elem);
            }
        }

        else if (strcmp(command, "list_insert_ordered") == 0) {
            char listName[100];
            int value;
            if (sscanf(input, "%*s %s %d", listName, &value) == 2) {
                struct list_item *new_item = malloc(sizeof(struct list_item));
                 if (new_item == NULL) {
                    continue;
                }
                new_item->data = value;
                list_insert_ordered(&my_list, &new_item->elem, less, NULL);
            } 
        }

        else if (strcmp(command, "list_max") == 0) {
            if (!list_empty(&my_list)) {
                struct list_elem *max_elem = list_max(&my_list, less, NULL);
                struct list_item *max_item = list_entry(max_elem, struct list_item, elem);
                printf("%d\n", max_item->data);
            }
        }

        else if (strcmp(command, "list_min") == 0) {
            if (!list_empty(&my_list)) {
                struct list_elem *min_elem = list_min(&my_list, less, NULL);
                struct list_item *min_item = list_entry(min_elem, struct list_item, elem);
                printf("%d\n", min_item->data);
            }
        }

        else if (strcmp(command, "list_size") == 0) {
            int size;
            size = list_size(&my_list);
            printf("%d\n", size);
        }

        else if (strcmp(command, "list_reverse") == 0) {
            list_reverse(&my_list);
        }

        else if (strcmp(command, "list_swap") == 0) {
            char listName[100];
            int index1, index2;
    
            if (sscanf(input, "%s %s %d %d", command, listName, &index1, &index2) == 4) {
                struct list_elem *elem1 = NULL, *elem2 = NULL;
                int idx = 0;
                for (struct list_elem *e = list_begin(&my_list); e != list_end(&my_list); e = list_next(e)) {
                    if (idx == index1) {
                        elem1 = e;
                    } else if (idx == index2) {
                        elem2 = e;
                    }

                    if (elem1 && elem2) break;
                    idx++;
                }
        
                if (elem1 != NULL && elem2 != NULL) {
                    list_swap(elem1, elem2);
                }
            }
        }

        else if (strcmp(command, "list_sort") == 0) {
            char listName[100];

            if (sscanf(input, "%s %s", command, &my_list) == 2) {
                list_sort(&my_list, less, NULL);
            }
        }

        else if (strcmp(command, "list_splice") == 0) {
            char srcListName[100], destListName[100];
            int srcStartIndex, destIndex, srcEndIndex;
            struct list *srcList = NULL, *destList = NULL;

            if (sscanf(input, "%*s %s %d %s %d %d", destListName, &destIndex, srcListName, &srcStartIndex, &srcEndIndex) == 5) {
                if (strcmp(srcListName, "list0") == 0) {
                    srcList = &my_list;
                } else if (strcmp(srcListName, "list1") == 0) {
                    srcList = &my_list2;
                }

                if (strcmp(destListName, "list0") == 0) {
                    destList = &my_list;
                } else if (strcmp(destListName, "list1") == 0) {
                    destList = &my_list2;
                }

                if (srcList && destList) {
                    struct list_elem *before = list_begin(destList);
                    for (int i = 0; i < destIndex && before != list_end(destList); i++) {
                        before = list_next(before);
                    }

                    struct list_elem *first = list_begin(srcList);
                    for (int i = 0; i < srcStartIndex && first != list_end(srcList); i++) {
                        first = list_next(first);
                    }

                    struct list_elem *last = first;
                    for (int i = srcStartIndex; i < srcEndIndex-1 && last != list_end(srcList); i++) {
                        last = list_next(last);
                    }

                    last = list_next(last);
                    list_splice(before, first, last);
                }
            }
        }

        else if (strcmp(command, "list_unique") == 0) {
            char listName1[100], listName2[100] = "";
            int args = sscanf(input, "%*s %s %s", listName1, listName2);

            struct list *listPtr = NULL, *duplicatesListPtr = NULL;
            if (strcmp(listName1, "list0") == 0) {
                listPtr = &my_list;
            } else if (strcmp(listName1, "list1") == 0) {
                listPtr = &my_list2;
            }

            if (args == 2) {
                if (strcmp(listName2, "list0") == 0) {
                    duplicatesListPtr = &my_list;
                } else if (strcmp(listName2, "list1") == 0) {
                    duplicatesListPtr = &my_list2;
                }
            }

            if (listPtr != NULL) {
                struct list tempList;
                list_init(&tempList);
                list_unique(listPtr, args == 2 ? &tempList : NULL, less, NULL);

                if (args == 2 && duplicatesListPtr != NULL) {
                    struct list_elem *e, *next;
                    for (e = list_begin(&tempList); e != list_end(&tempList); e = next) {
                        next = list_next(e);
                        list_remove(e);
                        list_push_back(duplicatesListPtr, e);
                    }
                }
            }
        }

        // MARK: Bitmap

        else if (sscanf(input, "bitmap_mark %s %d", name, &arg) == 2) {
            int idx = find_bitmap_index(name);
            if (idx >= 0 && idx < MAX_BITMAPS && bitmaps[idx] != NULL) {
                bitmap_set(bitmaps[idx], arg, true);
            }
        } 

        else if (sscanf(input, "bitmap_all %s %d %d", name, &arg, &arg2) == 3) {
            int idx = find_bitmap_index(name);
            if (idx >= 0 && idx < MAX_BITMAPS && bitmaps[idx] != NULL) {
                printf("%s\n", bitmap_all(bitmaps[idx], arg, arg2) ? "true" : "false");
            }
        }

        else if (strcmp(command, "bitmap_any") == 0) {
            char bitmapName[100];
            int start, cnt;
            struct bitmap *targetBitmap = NULL;

            if (sscanf(input, "%s %s %d %d", command, bitmapName, &start, &cnt) == 4) {
                if (strncmp(bitmapName, "bm", 2) == 0) {
                    int idx = atoi(bitmapName + 2);
                    if (idx >= 0 && idx < MAX_BITMAPS) {
                        targetBitmap = bitmaps[idx];
                    }
            }

                if (targetBitmap != NULL) {
                    bool result = bitmap_any(targetBitmap, start, cnt);
                    printf("%s\n", result ? "true" : "false");
                }
            }
        }

        else if (strcmp(command, "bitmap_contains") == 0) {
            char bitmapName[100];
            int start, cnt;
            int valueInput;
            struct bitmap *targetBitmap = NULL;

         if (sscanf(input, "%s %s %d %d %d", command, bitmapName, &start, &cnt, &valueInput) == 5) {
                bool value = valueInput != 0;
                int idx = atoi(bitmapName + 2);
                if (idx >= 0 && idx < MAX_BITMAPS) {
                    targetBitmap = bitmaps[idx]; 
                }

                if (targetBitmap != NULL) {
                    bool result = bitmap_contains(targetBitmap, start, cnt, value);
                    printf("Result: %s\n", result ? "true" : "false");
                }
            }
        }

        else if (strcmp(command, "bitmap_count") == 0) {
            char bitmapName[100];
            int start, cnt, valueInt;
            struct bitmap *targetBitmap = NULL;

            if (sscanf(input, "%s %s %d %d %d", command, bitmapName, &start, &cnt, &valueInt) == 5) {
                bool value = valueInt != 0;
                int idx = atoi(bitmapName + 2);
                if (idx >= 0 && idx < MAX_BITMAPS) {
                    targetBitmap = bitmaps[idx];
                }

                if (targetBitmap != NULL) {
                    size_t count = bitmap_count(targetBitmap, start, cnt, value);
                    printf("%zu\n", count);
                } else {
                    printf("Bitmap '%s' not found.\n", bitmapName);
                }
            }
        }


        else if (strcmp(command, "bitmap_dump") == 0) {
            char bitmapName[100];
            struct bitmap *targetBitmap = NULL;

            if (sscanf(input, "%s %s", command, bitmapName) == 2) {
                int idx = atoi(bitmapName + 2);
                if (idx >= 0 && idx < MAX_BITMAPS) {
                    targetBitmap = bitmaps[idx];
                }

                if (targetBitmap != NULL) {
                    size_t n_bits = bitmap_size(targetBitmap);
                    for (size_t i = 0; i < n_bits; i++) {
                        printf("%d", bitmap_test(targetBitmap, i) ? 1 : 0);
                    }
                    printf("\n");

                    // 메모리의 내용을 16진수로 출력하는 부분은 제거함
                }
            }
        }

        else if (strcmp(command, "bitmap_expand") == 0) {
            char bitmapName[100];
            struct bitmap *targetBitmap = NULL;
            int expandSize;

            if (sscanf(input, "%s %s %d", command, bitmapName, &expandSize) == 3) {
                int idx = atoi(bitmapName + 2);
                if (idx >= 0 && idx < MAX_BITMAPS && bitmaps[idx] != NULL) {
                    bitmaps[idx] = bitmap_expand(bitmaps[idx], expandSize);
                }
            }
        }

        else if (strcmp(command, "bitmap_set_all") == 0) {
             char bitmapName[100];
            int value;
            if (sscanf(input, "%*s %s %d", bitmapName, &value) == 2) {
                bool value = (value != 0); // Convert integer input to boolean
                int idx = atoi(bitmapName + 2);
                if (idx >= 0 && idx < MAX_BITMAPS && bitmaps[idx] != NULL) {
                    bm0 = bitmaps[idx];
                    bitmap_set_all(bm0, value);
                }
            }
        }
    }
    
    return 0;
}
